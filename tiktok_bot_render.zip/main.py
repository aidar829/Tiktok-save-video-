
from flask import Flask
from threading import Thread
import telebot
import requests

TOKEN = '8096692804:AAHb62IXxs_23y_r6tGiSZvsCf0dCD4VTs4'
bot = telebot.TeleBot(TOKEN)

def get_tiktok_video(url):
    api_url = f"https://tikwm.com/api/?url={url}"
    try:
        response = requests.get(api_url)
        data = response.json()
        return data['data']['play']
    except:
        return None

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 Привет! Пришли ссылку на TikTok — я скачаю видео без водяного знака.")

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    video_link = get_tiktok_video(message.text)
    if video_link:
        bot.send_video(message.chat.id, video_link)
    else:
        bot.reply_to(message, "❌ Не получилось. Убедись, что это ссылка на TikTok.")

app = Flask('')

@app.route('/')
def home():
    return "Я жив!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

keep_alive()
bot.infinity_polling()
